import React from 'react'

export default class HomePage extends React.Component{

    render(){
        return(
            <div class="jumbotron jumbotron-fluid text-center">
                <div class="container">
                    <h1 class="display-3">Welcome to React</h1>
                  
                </div>
            </div>
        )
    }
}